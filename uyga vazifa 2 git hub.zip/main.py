print("******")
print("******")
print("******")

print("\n")

print("   *")
print("  ***")
print(" *****")
print("*******")

print("\n")

print("   |   ")
print("-------")
print("   |   ")

print("\n")

print("-------")

print("\n")

print("            *")
print("          * *")
print("        *   *")
print("      *     *")
print("    *       *")
print("  *         *")
print("*           *")
print("*************")

print("\n")

print("        ***")
print("     **     **")
print("   **         **")
print("  *             *")
print("   **         **")
print("     **     **")
print("        ***")
print("\n")
print("        ***")
print("     *********")
print("   *************")
print("  ****************")
print("   **************")
print("     **********")
print("        ***")
